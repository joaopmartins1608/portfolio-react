import './App.css';

function App() {
  const projetos = [
    {
      titulo: 'Buscador de CEP',
      tech: 'React + API',
      descricao:
        'Aplicação que consome API do ViaCEP para autocompletar endereços.',
      link: 'https://github.com/joaopmartins1608/portfolio-react',
    },
    {
      titulo: 'Sistema Bancário',
      tech: 'Java + POO',
      descricao:
        'Simulador de caixa eletrônico com lógica de saques, depósitos e validações.',
      link: 'https://github.com/joaopmartins1608/portfolio-java',
    },
    {
      titulo: 'Banco de Dados Suporte',
      tech: 'SQL + SQLite',
      descricao:
        'Estrutura de banco de dados para gestão de tickets de atendimento e SLA.',
      link: 'https://github.com/joaopmartins1608/repositorio-sql',
    },
  ];

  return (
    <div className="portfolio">
      <header className="header">
        <h1>Seu Nome Aqui</h1>
        <p>Estudante de Sistemas de Informação | Dev em Formação</p>
        <div className="tags">
          <span>☕ Java</span>
          <span>⚛️ React</span>
          <span>💾 SQL</span>
        </div>
      </header>

      <section className="sobre">
        <h2>Sobre Mim</h2>
        <p>
          Apaixonado por tecnologia e resolução de problemas. Estou migrando da
          teoria para a prática, construindo projetos que unem lógica de backend
          com interfaces modernas. Busco minha primeira oportunidade como
          Estagiário ou Suporte Técnico.
        </p>
      </section>

      <section className="projetos-container">
        <h2>Meus Projetos</h2>
        <div className="grid">
          {projetos.map((proj, index) => (
            <div key={index} className="card">
              <h3>{proj.titulo}</h3>
              <span className="badge">{proj.tech}</span>
              <p>{proj.descricao}</p>
              <a href={proj.link} target="_blank" rel="noopener noreferrer">
                Ver no GitHub ➜
              </a>
            </div>
          ))}
        </div>
      </section>

      <footer className="footer">
        <p>Pronto para novos desafios! 🚀</p>
        <button
          onClick={() =>
            window.open(
              'https://www.linkedin.com/in/joão-pedro-padilhamartins/ '
            )
          }
        >
          Me chame no LinkedIn
        </button>
      </footer>
    </div>
  );
}

export default App;
