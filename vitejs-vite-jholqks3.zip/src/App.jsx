import { useState } from 'react';
import './App.css';
// REMOVI A LINHA QUE DAVA ERRO (import react-icons)

function App() {
  const [input, setInput] = useState('');
  const [cep, setCep] = useState({});

  async function handleSearch() {
    if (input === '') {
      alert('Preencha algum CEP!');
      return;
    }

    try {
      const response = await fetch(`https://viacep.com.br/ws/${input}/json`);
      const data = await response.json();

      if (data.erro) {
        alert('Ops! CEP não encontrado.');
        setInput('');
        return;
      }

      setCep(data);
      setInput('');
    } catch {
      alert('Ops! Erro ao buscar.');
      setInput('');
    }
  }

  return (
    <div className="container">
      <h1 className="title">Buscador de CEP 📍</h1>

      <div className="containerInput">
        <input
          type="text"
          placeholder="Digite seu cep..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />

        {/* Aqui usamos um emoji no lugar do ícone quebrado */}
        <button className="buttonSearch" onClick={handleSearch}>
          🔍 Buscar
        </button>
      </div>

      {Object.keys(cep).length > 0 && (
        <main className="main">
          <h2>CEP: {cep.cep}</h2>
          <span>{cep.logradouro}</span>
          <span>{cep.bairro}</span>
          <span>
            {cep.localidade} - {cep.uf}
          </span>
        </main>
      )}
    </div>
  );
}

export default App;
